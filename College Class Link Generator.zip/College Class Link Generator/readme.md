#Tool Name: CUESC ZOOM CLASS GENERATOR

#Requirements:
    tkinter
    pandas
#Python:
    3
